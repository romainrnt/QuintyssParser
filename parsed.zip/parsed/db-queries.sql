-- Requêtes SQL pour insérer le template multilingue "Template HeroSection - 21/03/2025" dans la base de données Quintyss
-- Générées le 21/03/2025 19:03:40

-- 1. Insertion du modèle
INSERT INTO models_table (
  identifier,
  name,
  slug,
  category,
  description,
  requirement_level
) VALUES (
  '27d2e149-493a-4212-acb7-709ab745ce8b', -- identifier
  'Template HeroSection - 21/03/2025', -- name
  'template-herosection-21032025', -- slug
  'converted', -- category
  'Template converti avec support multilingue (fr, en, de, es, it, pt)', -- description
  'Starter' -- requirement_level
);

-- 2. Insertion du template avec traductions
INSERT INTO site_content_templates_table (
  identifier,
  model_identifier,
  content,
  version,
  tags,
  required_subscription
) VALUES (
  '4dea31f5-075e-4ab7-81bb-724dab6bbb97', -- identifier
  '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
  jsonb_build_object(
    'id', '4dea31f5-075e-4ab7-81bb-724dab6bbb97',
    'name', 'Template HeroSection - 21/03/2025',
    'structure', jsonb_build_array(
      jsonb_build_object(
        'id', 'page-1',
        'name', jsonb_build_object(
          'fr', 'Accueil',
          'en', 'Home',
          'de', 'Startseite',
          'es', 'Inicio',
          'it', 'Home',
          'pt', 'Início',
        ),
        'slug', 'examplecomponent',
        'layout', 'default',
        'section', 'HeroSection',
        'widgets', jsonb_build_array(
          jsonb_build_object(
            'id', 'hero-media-1c7408',
            'type', 'MediaWidget',
            'props', jsonb_build_object(
              'tag', 'img',
              'alt', 'Logo de l''entreprise',
              'className', 'w-full h-full object-contain',
            )
          ),
          jsonb_build_object(
            'id', 'hero-media-bb0ce8',
            'type', 'MediaWidget',
            'props', jsonb_build_object(
              'tag', 'img',
              'alt', 'Image de héros',
              'className', 'w-full h-full object-cover',
            )
          ),
          jsonb_build_object(
            'id', 'hero-contactez-nous-button-6fc2ab',
            'type', 'ButtonWidget',
            'props', jsonb_build_object(
              'tag', 'button',
              'text', 'Contactez-nous',
              'className', 'hidden md:inline-block bg-white text-blue-700 px-6 py-2 rounded-full font-medium',
            )
          ),
          jsonb_build_object(
            'id', 'hero-nos services-button-ba17eb',
            'type', 'ButtonWidget',
            'props', jsonb_build_object(
              'tag', 'button',
              'text', 'Nos services',
              'className', 'bg-white text-blue-700 px-8 py-3 rounded-full font-semibold text-lg',
            )
          ),
          jsonb_build_object(
            'id', 'hero-nos réalisation-button-468ce8',
            'type', 'ButtonWidget',
            'props', jsonb_build_object(
              'tag', 'button',
              'text', 'Nos réalisations',
              'className', 'bg-transparent border-2 border-white text-white px-8 py-3 rounded-full font-semibold text-lg',
            )
          ),
          jsonb_build_object(
            'id', 'hero-transforme-text-d332e5',
            'type', 'TextWidget',
            'props', jsonb_build_object(
              'tag', 'h1',
              'type', 'editor',
              'text', 'Transformez vos idées en réalité',
              'className', 'text-4xl md:text-6xl font-bold mb-6',
            )
          ),
          jsonb_build_object(
            'id', 'hero-notre équi-text-495d6f',
            'type', 'TextWidget',
            'props', jsonb_build_object(
              'tag', 'p',
              'type', 'editor',
              'text', 'Notre équipe d''experts est prête à vous accompagner dans tous vos projets digitaux.
            Découvrez nos services et nos réalisations.',
              'className', 'text-xl mb-8 opacity-90',
            )
          ),
          jsonb_build_object(
            'id', 'hero-pourquoi n-text-520ad3',
            'type', 'TextWidget',
            'props', jsonb_build_object(
              'tag', 'h2',
              'type', 'editor',
              'text', 'Pourquoi nous choisir ?',
              'className', 'text-3xl font-bold text-center text-gray-800 mb-8',
            )
          ),
          jsonb_build_object(
            'id', 'hero-+500-text-10faad',
            'type', 'TextWidget',
            'props', jsonb_build_object(
              'tag', 'span',
              'type', 'editor',
              'text', '+500',
              'className', 'text-4xl font-bold text-blue-700',
            )
          ),
          jsonb_build_object(
            'id', 'hero-projets ré-text-0994d0',
            'type', 'TextWidget',
            'props', jsonb_build_object(
              'tag', 'p',
              'type', 'editor',
              'text', 'Projets réalisés',
              'className', 'text-gray-600 mt-2',
            )
          ),
          jsonb_build_object(
            'id', 'hero-98%-text-f2b6d6',
            'type', 'TextWidget',
            'props', jsonb_build_object(
              'tag', 'span',
              'type', 'editor',
              'text', '98%',
              'className', 'text-4xl font-bold text-blue-700',
            )
          ),
          jsonb_build_object(
            'id', 'hero-clients sa-text-341b1b',
            'type', 'TextWidget',
            'props', jsonb_build_object(
              'tag', 'p',
              'type', 'editor',
              'text', 'Clients satisfaits',
              'className', 'text-gray-600 mt-2',
            )
          ),
          jsonb_build_object(
            'id', 'hero-24/7-text-c30145',
            'type', 'TextWidget',
            'props', jsonb_build_object(
              'tag', 'span',
              'type', 'editor',
              'text', '24/7',
              'className', 'text-4xl font-bold text-blue-700',
            )
          ),
          jsonb_build_object(
            'id', 'hero-support cl-text-375830',
            'type', 'TextWidget',
            'props', jsonb_build_object(
              'tag', 'p',
              'type', 'editor',
              'text', 'Support client',
              'className', 'text-gray-600 mt-2',
            )
          )
        )
      )
    ),
    'style', jsonb_build_object(
      'theme', 'light',
      'colors', jsonb_build_object(
        'primary', '#0D6EFD',
        'secondary', '#6C757D',
      ),
      'typography', jsonb_build_object(
        'fontFamily', 'Roboto',
      )
    ),
    'translations', jsonb_build_object(
      'fr', jsonb_build_object(
        'media_alt_media-465def5b', 'Logo de l''entreprise',
        'media_alt_media-0fe5437a', 'Image de héros',
        'button_button-4d145a45', 'Contactez-nous',
        'button_button-4b94514b', 'Nos services',
        'button_button-f931e69d', 'Nos réalisations',
        'text_text-72fe1f12', 'Transformez vos idées en réalité',
        'text_text-085eee0e', 'Notre équipe d''experts est prête à vous accompagner dans tous vos projets digitaux.
            Découvrez nos services et nos réalisations.',
        'text_text-fa838f13', 'Pourquoi nous choisir ?',
        'text_text-ec4a65d0', '+500',
        'text_text-c602e0ea', 'Projets réalisés',
        'text_text-1c1dfeb9', '98%',
        'text_text-caaa449d', 'Clients satisfaits',
        'text_text-37646bed', '24/7',
        'text_text-fd49353e', 'Soutenir le client',
        'media_alt_hero-media-1c7408', 'Logo de l''entreprise',
        'media_alt_hero-media-bb0ce8', 'Image de héros',
        'button_hero-contactez-nous-button-6fc2ab', 'Contactez-nous',
        'button_hero-nos services-button-ba17eb', 'Nos services',
        'button_hero-nos réalisation-button-468ce8', 'Nos réalisations',
        'text_hero-transforme-text-d332e5', 'Transformez vos idées en réalité',
        'text_hero-notre équi-text-495d6f', 'Notre équipe d''experts est prête à vous accompagner dans tous vos projets digitaux.
            Découvrez nos services et nos réalisations.',
        'text_hero-pourquoi n-text-520ad3', 'Pourquoi nous choisir ?',
        'text_hero-+500-text-10faad', '+500',
        'text_hero-projets ré-text-0994d0', 'Projets réalisés',
        'text_hero-98%-text-f2b6d6', '98%',
        'text_hero-clients sa-text-341b1b', 'Clients satisfaits',
        'text_hero-24/7-text-c30145', '24/7',
        'text_hero-support cl-text-375830', 'Soutenir le client',
      ),
      'en', jsonb_build_object(
        'media_alt_media-465def5b', 'Logo de l''entreprise',
        'media_alt_media-0fe5437a', 'Image de héros',
        'button_button-4d145a45', 'Contactez-nous',
        'button_button-4b94514b', 'Nos services',
        'button_button-f931e69d', 'Nos réalisations',
        'text_text-72fe1f12', 'Transformez vos idées en réalité',
        'text_text-085eee0e', 'Notre équipe d''experts est prête à vous accompagner dans tous vos projets digitaux.
            Découvrez nos services et nos réalisations.',
        'text_text-fa838f13', 'Pourquoi nous choisir ?',
        'text_text-ec4a65d0', '+500',
        'text_text-c602e0ea', 'Projets réalisés',
        'text_text-1c1dfeb9', '98%',
        'text_text-caaa449d', 'Clients satisfaits',
        'text_text-37646bed', '24/7',
        'text_text-fd49353e', 'Support client',
        'media_alt_hero-media-1c7408', 'Logo de l''entreprise',
        'media_alt_hero-media-bb0ce8', 'Image de héros',
        'button_hero-contactez-nous-button-6fc2ab', 'Contactez-nous',
        'button_hero-nos services-button-ba17eb', 'Nos services',
        'button_hero-nos réalisation-button-468ce8', 'Nos réalisations',
        'text_hero-transforme-text-d332e5', 'Transformez vos idées en réalité',
        'text_hero-notre équi-text-495d6f', 'Notre équipe d''experts est prête à vous accompagner dans tous vos projets digitaux.
            Découvrez nos services et nos réalisations.',
        'text_hero-pourquoi n-text-520ad3', 'Pourquoi nous choisir ?',
        'text_hero-+500-text-10faad', '+500',
        'text_hero-projets ré-text-0994d0', 'Projets réalisés',
        'text_hero-98%-text-f2b6d6', '98%',
        'text_hero-clients sa-text-341b1b', 'Clients satisfaits',
        'text_hero-24/7-text-c30145', '24/7',
        'text_hero-support cl-text-375830', 'Support client',
      ),
      'de', jsonb_build_object(
        'media_alt_media-465def5b', 'Logo des Unternehmens',
        'media_alt_media-0fe5437a', 'Bild des Helden',
        'button_button-4d145a45', 'Kontaktieren Sie uns',
        'button_button-4b94514b', 'Nos-Dienste',
        'button_button-f931e69d', 'Unsere Realisationen',
        'text_text-72fe1f12', 'Setzen Sie Ihre Ideen in die Realität um',
        'text_text-085eee0e', 'Notre équipe d''experts est prête à vous accompagner dans tous vos projets digitaux.
            Découvrez nos services et nos réalisations.',
        'text_text-fa838f13', 'Warum sollten wir uns entscheiden?',
        'text_text-ec4a65d0', '+500',
        'text_text-c602e0ea', 'Umgesetzte Projekte',
        'text_text-1c1dfeb9', '98%',
        'text_text-caaa449d', 'Zufriedene Kunden',
        'text_text-37646bed', '24/7',
        'text_text-fd49353e', 'Kunde unterstützen',
        'media_alt_hero-media-1c7408', 'Logo des Unternehmens',
        'media_alt_hero-media-bb0ce8', 'Bild des Helden',
        'button_hero-contactez-nous-button-6fc2ab', 'Kontaktieren Sie uns',
        'button_hero-nos services-button-ba17eb', 'Nos-Dienste',
        'button_hero-nos réalisation-button-468ce8', 'Unsere Realisationen',
        'text_hero-transforme-text-d332e5', 'Setzen Sie Ihre Ideen in die Realität um',
        'text_hero-notre équi-text-495d6f', 'Notre équipe d''experts est prête à vous accompagner dans tous vos projets digitaux.
            Découvrez nos services et nos réalisations.',
        'text_hero-pourquoi n-text-520ad3', 'Warum sollten wir uns entscheiden?',
        'text_hero-+500-text-10faad', '+500',
        'text_hero-projets ré-text-0994d0', 'Umgesetzte Projekte',
        'text_hero-98%-text-f2b6d6', '98%',
        'text_hero-clients sa-text-341b1b', 'Zufriedene Kunden',
        'text_hero-24/7-text-c30145', '24/7',
        'text_hero-support cl-text-375830', 'Kunde unterstützen',
      ),
      'es', jsonb_build_object(
        'media_alt_media-465def5b', 'Logotipo de la empresa',
        'media_alt_media-0fe5437a', 'Imagen de héroe',
        'button_button-4d145a45', 'Contacte con nosotros',
        'button_button-4b94514b', 'Servicios',
        'button_button-f931e69d', 'Nuestras realizaciones',
        'text_text-72fe1f12', 'Convierta sus ideas en realidad',
        'text_text-085eee0e', 'Nuestro equipo de expertos está preparado para acompañarle en todos sus proyectos digitales.
            Descubra nuestros servicios y nuestras realizaciones.',
        'text_text-fa838f13', '¿Por qué elegimos?',
        'text_text-ec4a65d0', '+500',
        'text_text-c602e0ea', 'Proyectos realizados',
        'text_text-1c1dfeb9', '98%',
        'text_text-caaa449d', 'Clientes satisfechos',
        'text_text-37646bed', '24/7',
        'text_text-fd49353e', 'Apoyo al cliente',
        'media_alt_hero-media-1c7408', 'Logotipo de la empresa',
        'media_alt_hero-media-bb0ce8', 'Imagen de héroe',
        'button_hero-contactez-nous-button-6fc2ab', 'Contacte con nosotros',
        'button_hero-nos services-button-ba17eb', 'Servicios',
        'button_hero-nos réalisation-button-468ce8', 'Nuestras realizaciones',
        'text_hero-transforme-text-d332e5', 'Convierta sus ideas en realidad',
        'text_hero-notre équi-text-495d6f', 'Nuestro equipo de expertos está preparado para acompañarle en todos sus proyectos digitales.
            Descubra nuestros servicios y nuestras realizaciones.',
        'text_hero-pourquoi n-text-520ad3', '¿Por qué elegimos?',
        'text_hero-+500-text-10faad', '+500',
        'text_hero-projets ré-text-0994d0', 'Proyectos realizados',
        'text_hero-98%-text-f2b6d6', '98%',
        'text_hero-clients sa-text-341b1b', 'Clientes satisfechos',
        'text_hero-24/7-text-c30145', '24/7',
        'text_hero-support cl-text-375830', 'Apoyo al cliente',
      ),
      'it', jsonb_build_object(
        'media_alt_media-465def5b', 'Logo dell''azienda',
        'media_alt_media-0fe5437a', 'Immagine dell''eroe',
        'button_button-4d145a45', 'Contattateci',
        'button_button-4b94514b', 'Servizi Nos',
        'button_button-f931e69d', 'Le nostre realizzazioni',
        'text_text-72fe1f12', 'Trasformare le vostre idee in realtà',
        'text_text-085eee0e', 'La nostra équipe di esperti è pronta ad accompagnarvi nei vostri progetti digitali.
            Scoprite i nostri servizi e le nostre realizzazioni.',
        'text_text-fa838f13', 'Pourquoi nous choisir?',
        'text_text-ec4a65d0', '+500',
        'text_text-c602e0ea', 'Progetti realizzati',
        'text_text-1c1dfeb9', '98%',
        'text_text-caaa449d', 'Clienti soddisfatti',
        'text_text-37646bed', '24/7',
        'text_text-fd49353e', 'Supporto clienti',
        'media_alt_hero-media-1c7408', 'Logo dell''azienda',
        'media_alt_hero-media-bb0ce8', 'Immagine dell''eroe',
        'button_hero-contactez-nous-button-6fc2ab', 'Contattateci',
        'button_hero-nos services-button-ba17eb', 'Servizi Nos',
        'button_hero-nos réalisation-button-468ce8', 'Le nostre realizzazioni',
        'text_hero-transforme-text-d332e5', 'Trasformare le vostre idee in realtà',
        'text_hero-notre équi-text-495d6f', 'La nostra équipe di esperti è pronta ad accompagnarvi nei vostri progetti digitali.
            Scoprite i nostri servizi e le nostre realizzazioni.',
        'text_hero-pourquoi n-text-520ad3', 'Pourquoi nous choisir?',
        'text_hero-+500-text-10faad', '+500',
        'text_hero-projets ré-text-0994d0', 'Progetti realizzati',
        'text_hero-98%-text-f2b6d6', '98%',
        'text_hero-clients sa-text-341b1b', 'Clienti soddisfatti',
        'text_hero-24/7-text-c30145', '24/7',
        'text_hero-support cl-text-375830', 'Supporto clienti',
      ),
      'pt', jsonb_build_object(
        'media_alt_media-465def5b', 'Logotipo da empresa',
        'media_alt_media-0fe5437a', 'Imagem de heróis',
        'button_button-4d145a45', 'Entre em contato conosco',
        'button_button-4b94514b', 'Nos serviços',
        'button_button-f931e69d', 'Nossas realizações',
        'text_text-72fe1f12', 'Transforme suas ideias em realidade',
        'text_text-085eee0e', 'Nossa equipe de especialistas está pronta para acompanhá-lo em seus projetos digitais.
            Conheça nossos serviços e nossas realizações.',
        'text_text-fa838f13', 'Por que escolhemos?',
        'text_text-ec4a65d0', '+500',
        'text_text-c602e0ea', 'Projetos realizados',
        'text_text-1c1dfeb9', '98%',
        'text_text-caaa449d', 'Satisfação dos clientes',
        'text_text-37646bed', '24/7',
        'text_text-fd49353e', 'Suporte ao cliente',
        'media_alt_hero-media-1c7408', 'Logotipo da empresa',
        'media_alt_hero-media-bb0ce8', 'Imagem de heróis',
        'button_hero-contactez-nous-button-6fc2ab', 'Entre em contato conosco',
        'button_hero-nos services-button-ba17eb', 'Nos serviços',
        'button_hero-nos réalisation-button-468ce8', 'Nossas realizações',
        'text_hero-transforme-text-d332e5', 'Transforme suas ideias em realidade',
        'text_hero-notre équi-text-495d6f', 'Nossa equipe de especialistas está pronta para acompanhá-lo em seus projetos digitais.
            Conheça nossos serviços e nossas realizações.',
        'text_hero-pourquoi n-text-520ad3', 'Por que escolhemos?',
        'text_hero-+500-text-10faad', '+500',
        'text_hero-projets ré-text-0994d0', 'Projetos realizados',
        'text_hero-98%-text-f2b6d6', '98%',
        'text_hero-clients sa-text-341b1b', 'Satisfação dos clientes',
        'text_hero-24/7-text-c30145', '24/7',
        'text_hero-support cl-text-375830', 'Suporte ao cliente',
      ),
    ),
    'createdAt', CURRENT_TIMESTAMP,
    'updatedAt', CURRENT_TIMESTAMP
  ),
  '1.0', -- version
  jsonb_build_array('converted', 'html', 'multilingual'), -- tags
  'Starter' -- required_subscription
);

-- 3. Mettre à jour la référence du template dans le modèle
UPDATE models_table 
SET site_content_template_identifier = '4dea31f5-075e-4ab7-81bb-724dab6bbb97' 
WHERE identifier = '27d2e149-493a-4212-acb7-709ab745ce8b';

-- 4. Créer les pages
DO $
DECLARE
  page_id UUID;
BEGIN
  -- Page: ExampleComponent (examplecomponent)
  INSERT INTO pages_table (
    identifier,
    model_identifier,
    name,
    slug,
    description,
    is_homepage,
    order_index
  ) VALUES (
    '493c0d28-08eb-40a1-99b1-15ac6673eb02', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    'ExampleComponent', -- name
    'examplecomponent', -- slug
    'Page ExampleComponent (HeroSection) du template', -- description
    true, -- is_homepage
    0 -- order_index
  );

  -- Associer la page au modèle
  INSERT INTO model_pages_table (
    identifier,
    model_identifier,
    page_identifier
  ) VALUES (
    '6320641c-ca78-4057-85e0-449f2af1596b', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    '493c0d28-08eb-40a1-99b1-15ac6673eb02' -- page_identifier
  );

END $;

-- 5. Insérer et associer les widgets
DO $
DECLARE
  widget_id UUID;
BEGIN
  -- Widget: hero-media-1c7408 (Type: MediaWidget) - Page: examplecomponent
  INSERT INTO widgets_table (
    identifier,
    model_identifier,
    name,
    description,
    widget_type,
    default_props,
    version,
    requirement_level
  ) VALUES (
    'dcb09cf2-d63a-4b37-80da-fccb50436b33', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    'Widget hero-media-1c7408', -- name
    'Widget généré automatiquement pour ExampleComponent (HeroSection)', -- description
    'MediaWidget', -- widget_type
    jsonb_build_object(
      'tag', 'img',
      'alt', 'media_alt_hero-media-1c7408',
      'className', 'w-full h-full object-contain',
    ), -- default_props
    '1.0', -- version
    'Starter' -- requirement_level
  ) RETURNING identifier INTO widget_id;
  
  -- Associer le widget au modèle
  INSERT INTO model_widgets_table (
    identifier,
    model_identifier,
    widget_identifier
  ) VALUES (
    '6c213512-2ab1-4ba9-9d33-e21bf0380f00', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    widget_id -- widget_identifier
  );

  -- Widget: hero-media-bb0ce8 (Type: MediaWidget) - Page: examplecomponent
  INSERT INTO widgets_table (
    identifier,
    model_identifier,
    name,
    description,
    widget_type,
    default_props,
    version,
    requirement_level
  ) VALUES (
    '17ad4d03-fd89-4e67-be27-3ab71a508bbe', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    'Widget hero-media-bb0ce8', -- name
    'Widget généré automatiquement pour ExampleComponent (HeroSection)', -- description
    'MediaWidget', -- widget_type
    jsonb_build_object(
      'tag', 'img',
      'alt', 'media_alt_hero-media-bb0ce8',
      'className', 'w-full h-full object-cover',
    ), -- default_props
    '1.0', -- version
    'Starter' -- requirement_level
  ) RETURNING identifier INTO widget_id;
  
  -- Associer le widget au modèle
  INSERT INTO model_widgets_table (
    identifier,
    model_identifier,
    widget_identifier
  ) VALUES (
    '30e2d25b-4774-4f3d-abac-ff58158390e8', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    widget_id -- widget_identifier
  );

  -- Widget: hero-contactez-nous-button-6fc2ab (Type: ButtonWidget) - Page: examplecomponent
  INSERT INTO widgets_table (
    identifier,
    model_identifier,
    name,
    description,
    widget_type,
    default_props,
    version,
    requirement_level
  ) VALUES (
    '1358bdd1-1588-42cf-a066-dace0adf81dc', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    'Widget hero-contactez-nous-button-6fc2ab', -- name
    'Widget généré automatiquement pour ExampleComponent (HeroSection)', -- description
    'ButtonWidget', -- widget_type
    jsonb_build_object(
      'tag', 'button',
      'text', 'text_hero-contactez-nous-button-6fc2ab',
      'className', 'hidden md:inline-block bg-white text-blue-700 px-6 py-2 rounded-full font-medium',
    ), -- default_props
    '1.0', -- version
    'Starter' -- requirement_level
  ) RETURNING identifier INTO widget_id;
  
  -- Associer le widget au modèle
  INSERT INTO model_widgets_table (
    identifier,
    model_identifier,
    widget_identifier
  ) VALUES (
    '3a6010c3-edbd-49dd-a5f6-4ce99ef80a0b', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    widget_id -- widget_identifier
  );

  -- Widget: hero-nos services-button-ba17eb (Type: ButtonWidget) - Page: examplecomponent
  INSERT INTO widgets_table (
    identifier,
    model_identifier,
    name,
    description,
    widget_type,
    default_props,
    version,
    requirement_level
  ) VALUES (
    'ff37f01d-0abd-4d4d-8047-84a1e79ecbba', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    'Widget hero-nos services-button-ba17eb', -- name
    'Widget généré automatiquement pour ExampleComponent (HeroSection)', -- description
    'ButtonWidget', -- widget_type
    jsonb_build_object(
      'tag', 'button',
      'text', 'text_hero-nos services-button-ba17eb',
      'className', 'bg-white text-blue-700 px-8 py-3 rounded-full font-semibold text-lg',
    ), -- default_props
    '1.0', -- version
    'Starter' -- requirement_level
  ) RETURNING identifier INTO widget_id;
  
  -- Associer le widget au modèle
  INSERT INTO model_widgets_table (
    identifier,
    model_identifier,
    widget_identifier
  ) VALUES (
    '70dc0424-93c1-43c9-a6aa-07c27c3f0cf5', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    widget_id -- widget_identifier
  );

  -- Widget: hero-nos réalisation-button-468ce8 (Type: ButtonWidget) - Page: examplecomponent
  INSERT INTO widgets_table (
    identifier,
    model_identifier,
    name,
    description,
    widget_type,
    default_props,
    version,
    requirement_level
  ) VALUES (
    '28d3da66-8918-4aad-afb7-0b1462f53d10', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    'Widget hero-nos réalisation-button-468ce8', -- name
    'Widget généré automatiquement pour ExampleComponent (HeroSection)', -- description
    'ButtonWidget', -- widget_type
    jsonb_build_object(
      'tag', 'button',
      'text', 'text_hero-nos réalisation-button-468ce8',
      'className', 'bg-transparent border-2 border-white text-white px-8 py-3 rounded-full font-semibold text-lg',
    ), -- default_props
    '1.0', -- version
    'Starter' -- requirement_level
  ) RETURNING identifier INTO widget_id;
  
  -- Associer le widget au modèle
  INSERT INTO model_widgets_table (
    identifier,
    model_identifier,
    widget_identifier
  ) VALUES (
    '30748de0-189e-46e5-9eb1-277a8954db77', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    widget_id -- widget_identifier
  );

  -- Widget: hero-transforme-text-d332e5 (Type: TextWidget) - Page: examplecomponent
  INSERT INTO widgets_table (
    identifier,
    model_identifier,
    name,
    description,
    widget_type,
    default_props,
    version,
    requirement_level
  ) VALUES (
    'c13f0840-5761-477b-a934-4e4b62a7b8e8', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    'Widget hero-transforme-text-d332e5', -- name
    'Widget généré automatiquement pour ExampleComponent (HeroSection)', -- description
    'TextWidget', -- widget_type
    jsonb_build_object(
      'tag', 'h1',
      'type', 'editor',
      'text', 'text_hero-transforme-text-d332e5',
      'className', 'text-4xl md:text-6xl font-bold mb-6',
    ), -- default_props
    '1.0', -- version
    'Starter' -- requirement_level
  ) RETURNING identifier INTO widget_id;
  
  -- Associer le widget au modèle
  INSERT INTO model_widgets_table (
    identifier,
    model_identifier,
    widget_identifier
  ) VALUES (
    '6640eb32-f0cc-475e-8617-db297f4ca3f8', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    widget_id -- widget_identifier
  );

  -- Widget: hero-notre équi-text-495d6f (Type: TextWidget) - Page: examplecomponent
  INSERT INTO widgets_table (
    identifier,
    model_identifier,
    name,
    description,
    widget_type,
    default_props,
    version,
    requirement_level
  ) VALUES (
    'a2b2bc34-6d4f-448b-9365-2120ff4b6cc3', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    'Widget hero-notre équi-text-495d6f', -- name
    'Widget généré automatiquement pour ExampleComponent (HeroSection)', -- description
    'TextWidget', -- widget_type
    jsonb_build_object(
      'tag', 'p',
      'type', 'editor',
      'text', 'text_hero-notre équi-text-495d6f',
      'className', 'text-xl mb-8 opacity-90',
    ), -- default_props
    '1.0', -- version
    'Starter' -- requirement_level
  ) RETURNING identifier INTO widget_id;
  
  -- Associer le widget au modèle
  INSERT INTO model_widgets_table (
    identifier,
    model_identifier,
    widget_identifier
  ) VALUES (
    '5ae2b62d-ac0e-423e-82ae-ccf8d767693a', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    widget_id -- widget_identifier
  );

  -- Widget: hero-pourquoi n-text-520ad3 (Type: TextWidget) - Page: examplecomponent
  INSERT INTO widgets_table (
    identifier,
    model_identifier,
    name,
    description,
    widget_type,
    default_props,
    version,
    requirement_level
  ) VALUES (
    'b8f59b62-5924-4d3d-b716-df348a0fb1f6', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    'Widget hero-pourquoi n-text-520ad3', -- name
    'Widget généré automatiquement pour ExampleComponent (HeroSection)', -- description
    'TextWidget', -- widget_type
    jsonb_build_object(
      'tag', 'h2',
      'type', 'editor',
      'text', 'text_hero-pourquoi n-text-520ad3',
      'className', 'text-3xl font-bold text-center text-gray-800 mb-8',
    ), -- default_props
    '1.0', -- version
    'Starter' -- requirement_level
  ) RETURNING identifier INTO widget_id;
  
  -- Associer le widget au modèle
  INSERT INTO model_widgets_table (
    identifier,
    model_identifier,
    widget_identifier
  ) VALUES (
    'ed2161c5-b32d-4bcc-a530-59f41c41fcf2', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    widget_id -- widget_identifier
  );

  -- Widget: hero-+500-text-10faad (Type: TextWidget) - Page: examplecomponent
  INSERT INTO widgets_table (
    identifier,
    model_identifier,
    name,
    description,
    widget_type,
    default_props,
    version,
    requirement_level
  ) VALUES (
    '2a19928d-19b4-4a84-8b38-fe35d9a6515a', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    'Widget hero-+500-text-10faad', -- name
    'Widget généré automatiquement pour ExampleComponent (HeroSection)', -- description
    'TextWidget', -- widget_type
    jsonb_build_object(
      'tag', 'span',
      'type', 'editor',
      'text', 'text_hero-+500-text-10faad',
      'className', 'text-4xl font-bold text-blue-700',
    ), -- default_props
    '1.0', -- version
    'Starter' -- requirement_level
  ) RETURNING identifier INTO widget_id;
  
  -- Associer le widget au modèle
  INSERT INTO model_widgets_table (
    identifier,
    model_identifier,
    widget_identifier
  ) VALUES (
    'e7b80029-c184-4425-98a5-d09e2fa3e724', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    widget_id -- widget_identifier
  );

  -- Widget: hero-projets ré-text-0994d0 (Type: TextWidget) - Page: examplecomponent
  INSERT INTO widgets_table (
    identifier,
    model_identifier,
    name,
    description,
    widget_type,
    default_props,
    version,
    requirement_level
  ) VALUES (
    '80812927-63d9-4ea5-84ab-b9653d86e7d2', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    'Widget hero-projets ré-text-0994d0', -- name
    'Widget généré automatiquement pour ExampleComponent (HeroSection)', -- description
    'TextWidget', -- widget_type
    jsonb_build_object(
      'tag', 'p',
      'type', 'editor',
      'text', 'text_hero-projets ré-text-0994d0',
      'className', 'text-gray-600 mt-2',
    ), -- default_props
    '1.0', -- version
    'Starter' -- requirement_level
  ) RETURNING identifier INTO widget_id;
  
  -- Associer le widget au modèle
  INSERT INTO model_widgets_table (
    identifier,
    model_identifier,
    widget_identifier
  ) VALUES (
    '32950b92-2337-430b-9a4b-310affeb535c', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    widget_id -- widget_identifier
  );

  -- Widget: hero-98%-text-f2b6d6 (Type: TextWidget) - Page: examplecomponent
  INSERT INTO widgets_table (
    identifier,
    model_identifier,
    name,
    description,
    widget_type,
    default_props,
    version,
    requirement_level
  ) VALUES (
    '835f5218-2173-446a-a627-bc30ec9b7820', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    'Widget hero-98%-text-f2b6d6', -- name
    'Widget généré automatiquement pour ExampleComponent (HeroSection)', -- description
    'TextWidget', -- widget_type
    jsonb_build_object(
      'tag', 'span',
      'type', 'editor',
      'text', 'text_hero-98%-text-f2b6d6',
      'className', 'text-4xl font-bold text-blue-700',
    ), -- default_props
    '1.0', -- version
    'Starter' -- requirement_level
  ) RETURNING identifier INTO widget_id;
  
  -- Associer le widget au modèle
  INSERT INTO model_widgets_table (
    identifier,
    model_identifier,
    widget_identifier
  ) VALUES (
    '507f15d5-68ff-423d-bace-79ff9e2625e7', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    widget_id -- widget_identifier
  );

  -- Widget: hero-clients sa-text-341b1b (Type: TextWidget) - Page: examplecomponent
  INSERT INTO widgets_table (
    identifier,
    model_identifier,
    name,
    description,
    widget_type,
    default_props,
    version,
    requirement_level
  ) VALUES (
    '0a97c7a3-2496-486a-abb4-a892b5e931cc', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    'Widget hero-clients sa-text-341b1b', -- name
    'Widget généré automatiquement pour ExampleComponent (HeroSection)', -- description
    'TextWidget', -- widget_type
    jsonb_build_object(
      'tag', 'p',
      'type', 'editor',
      'text', 'text_hero-clients sa-text-341b1b',
      'className', 'text-gray-600 mt-2',
    ), -- default_props
    '1.0', -- version
    'Starter' -- requirement_level
  ) RETURNING identifier INTO widget_id;
  
  -- Associer le widget au modèle
  INSERT INTO model_widgets_table (
    identifier,
    model_identifier,
    widget_identifier
  ) VALUES (
    '8f458b6f-48d3-42e2-bc71-6e7390401746', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    widget_id -- widget_identifier
  );

  -- Widget: hero-24/7-text-c30145 (Type: TextWidget) - Page: examplecomponent
  INSERT INTO widgets_table (
    identifier,
    model_identifier,
    name,
    description,
    widget_type,
    default_props,
    version,
    requirement_level
  ) VALUES (
    '152ae9db-59df-4e59-b42c-81706ecc146d', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    'Widget hero-24/7-text-c30145', -- name
    'Widget généré automatiquement pour ExampleComponent (HeroSection)', -- description
    'TextWidget', -- widget_type
    jsonb_build_object(
      'tag', 'span',
      'type', 'editor',
      'text', 'text_hero-24/7-text-c30145',
      'className', 'text-4xl font-bold text-blue-700',
    ), -- default_props
    '1.0', -- version
    'Starter' -- requirement_level
  ) RETURNING identifier INTO widget_id;
  
  -- Associer le widget au modèle
  INSERT INTO model_widgets_table (
    identifier,
    model_identifier,
    widget_identifier
  ) VALUES (
    '03dabc32-c326-43cb-9209-3b50fffac89d', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    widget_id -- widget_identifier
  );

  -- Widget: hero-support cl-text-375830 (Type: TextWidget) - Page: examplecomponent
  INSERT INTO widgets_table (
    identifier,
    model_identifier,
    name,
    description,
    widget_type,
    default_props,
    version,
    requirement_level
  ) VALUES (
    '558df7c7-c4f2-4b20-bd07-efb8529f0b44', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    'Widget hero-support cl-text-375830', -- name
    'Widget généré automatiquement pour ExampleComponent (HeroSection)', -- description
    'TextWidget', -- widget_type
    jsonb_build_object(
      'tag', 'p',
      'type', 'editor',
      'text', 'text_hero-support cl-text-375830',
      'className', 'text-gray-600 mt-2',
    ), -- default_props
    '1.0', -- version
    'Starter' -- requirement_level
  ) RETURNING identifier INTO widget_id;
  
  -- Associer le widget au modèle
  INSERT INTO model_widgets_table (
    identifier,
    model_identifier,
    widget_identifier
  ) VALUES (
    '2456104d-6817-4d04-80ee-7aa0480d7c47', -- identifier
    '27d2e149-493a-4212-acb7-709ab745ce8b', -- model_identifier
    widget_id -- widget_identifier
  );

END $;

-- 6. Créer un site de test avec le template (à exécuter séparément si nécessaire)
/*
DO $
DECLARE
  content_id UUID;
BEGIN
  -- Créer une entrée de contenu pour le site de test
  INSERT INTO site_contents_table (
    identifier,
    model_identifier,
    content
  ) SELECT 
    gen_random_uuid() AS identifier,
    '27d2e149-493a-4212-acb7-709ab745ce8b' AS model_identifier,
    content AS content
  FROM 
    site_content_templates_table 
  WHERE 
    identifier = '4dea31f5-075e-4ab7-81bb-724dab6bbb97'
  RETURNING identifier INTO content_id;

  -- Créer le site de test
  INSERT INTO sites_table (
    identifier,
    content_identifier,
    name,
    domain,
    flag_deactivated
  ) VALUES (
    gen_random_uuid(), -- identifier
    content_id, -- content_identifier
    'Site test - Template HeroSection - 21/03/2025', -- name
    'template-herosection-21032025-test.quintyss.com', -- domain
    FALSE -- flag_deactivated
  );
END $;
*/

-- 7. Fonction pour mettre à jour les traductions (pour une utilisation future)
CREATE OR REPLACE FUNCTION update_template_translations(
  template_id UUID,
  lang_code TEXT,
  translations JSONB
) RETURNS VOID AS $
BEGIN
  UPDATE site_content_templates_table
  SET content = jsonb_set(
    content,
    ARRAY['translations', lang_code],
    translations,
    true
  )
  WHERE identifier = template_id;
END;
$ LANGUAGE plpgsql;

