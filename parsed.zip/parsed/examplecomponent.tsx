import WidgetMedia from '@Widget/Media';
import WidgetButton from '@Widget/Button';
import WidgetText from '@Widget/Text';
// HeroSection
import React from 'react';
/*REMOVE_IMPORT*/
import heroImage from '../assets/hero-image.jpg';
import logoImage from '../assets/logo.svg';

/**
 * Composant Hero avec différents éléments à transformer :
 * - Images -> WidgetMedia
 * - Boutons -> WidgetButton
 * - Textes -> WidgetText
 */
const HeroComponent = () => {
  const handleClick = () => {
    console.log('Bouton cliqué!');
  };
  return <div className="relative min-h-screen bg-gradient-to-b from-blue-900 to-indigo-700">
      {/* En-tête avec logo */}
      <header className="absolute top-0 left-0 right-0 p-6 flex justify-between items-center">
        <div className="w-36 h-12">
          <WidgetMedia modelId='hero-media-1c7408' alt='media_alt_hero-media-1c7408' global className="w-full h-full object-contain" />
        </div>
        <WidgetButton modelId='hero-contactez-nous-button-6fc2ab' global className="hidden md:inline-block bg-white text-blue-700 px-6 py-2 rounded-full font-medium" onClick={handleClick} />
      </header>

      {/* Section principale */}
      <div className="container mx-auto px-6 pt-32 pb-16 flex flex-col md:flex-row items-center">
        {/* Textes */}
        <div className="md:w-1/2 text-white z-10">
          <WidgetText modelId='hero-transforme-text-d332e5' type='editor' global className="text-4xl md:text-6xl font-bold mb-6" />
          <WidgetText modelId='hero-notre \xE9qui-text-495d6f' type='editor' global className="text-xl mb-8 opacity-90" />
          <div className="flex flex-col sm:flex-row gap-4">
            <WidgetButton modelId='hero-nos services-button-ba17eb' global className="bg-white text-blue-700 px-8 py-3 rounded-full font-semibold text-lg" onClick={handleClick} />
            <WidgetButton modelId='hero-nos r\xE9alisation-button-468ce8' global className="bg-transparent border-2 border-white text-white px-8 py-3 rounded-full font-semibold text-lg" onClick={handleClick} />
          </div>
        </div>

        {/* Image principale */}
        <div className="md:w-1/2 mt-12 md:mt-0 relative">
          <div className="w-full h-[400px] md:h-[500px] rounded-xl overflow-hidden">
            <WidgetMedia modelId='hero-media-bb0ce8' alt='media_alt_hero-media-bb0ce8' global className="w-full h-full object-cover" />
          </div>
        </div>
      </div>

      {/* Section de statistiques */}
      <div className="bg-white py-12">
        <div className="container mx-auto px-6">
          <WidgetText modelId='hero-pourquoi n-text-520ad3' type='editor' global className="text-3xl font-bold text-center text-gray-800 mb-8" />
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <WidgetText modelId='hero-+500-text-10faad' type='editor' global className="text-4xl font-bold text-blue-700" />
              <WidgetText modelId='hero-projets r\xE9-text-0994d0' type='editor' global className="text-gray-600 mt-2" />
            </div>
            <div className="text-center">
              <WidgetText modelId='hero-98%-text-f2b6d6' type='editor' global className="text-4xl font-bold text-blue-700" />
              <WidgetText modelId='hero-clients sa-text-341b1b' type='editor' global className="text-gray-600 mt-2" />
            </div>
            <div className="text-center">
              <WidgetText modelId='hero-24/7-text-c30145' type='editor' global className="text-4xl font-bold text-blue-700" />
              <WidgetText modelId='hero-support cl-text-375830' type='editor' global className="text-gray-600 mt-2" />
            </div>
          </div>
        </div>
      </div>
    </div>;
};
export default HeroComponent;